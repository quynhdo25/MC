import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
import gensim
from gensim.models import Word2Vec
from gensim.models import KeyedVectors
from gensim.models import FastText
import gensim.downloader as api
from nltk.tokenize import word_tokenize
import csv
import io
import fasttext
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from collections import defaultdict
import os
import sqlite3
from sklearn.decomposition import TruncatedSVD
import re
from nltk import tokenize
# import matplotlib.pyplot as plt
class hw3:

    ## QUES_1_3
    def get_word2vec_matrix(self,  words_list, word_vectors ):
        # first sort words_list and then complete the function
        new_list=sorted(words_list)
        vectors=[]
        non_exist=[]
        value =[]
        key=[]
        for x in new_list:
            if x in word_vectors:       
                words=word_vectors.get_vector(x)
                vectors.append(words)
                key.append(x)
            else:
                words=x
                non_exist.append(words)
        # tmp=[t[0] for t in vectors]
        # M=np.array(tmp)
        M=vectors
        for i in range(len(key)):
            value.append(i)
        word2Ind = {k:v for k,v in zip(key,value)}
        return M, word2Ind, non_exist

    # ques1_6    
    def load_glove():
        word_vectors = {}
        path = 'D:/downloads/glove.6B.300d.txt'
        f = open(path, 'r', encoding ='UTF-8')
        for line in f:
            values = line.split()
            word = values[0]
            vectors = np.asarray(values[1:], 'float32')
            word_vectors[word] = vectors
        f.close()
        return word_vectors
    
    def get_glove_matrix(self,  words_list ):
        # first sort words_list and then complete the function
        word_vectors = self.load_glove()
        new_list=sorted(words_list)
        vectors=[]
        non_exist=[]
        value =[]
        key=[]
        for x in new_list:
            if x in word_vectors:       
                words=word_vectors[x]
                vectors.append(words)
                key.append(x)
            else:
                words=x
                non_exist.append(words)
        # tmp=[t[0] for t in vectors]
        # M=np.array(tmp)
        M=vectors
        for i in range(0,len(key)):
            value.append(i)
        word2Ind = {k:v for k,v in zip(key,value)}
        return M, word2Ind, non_exist

    
    # ques1_7

    def get_fasttext_matrix(self,  words_list, training_text ):
        # first sort words_list and then complete the function
        def load_fasttext(fname='D:/downloads/wiki-news-300d-1M.vec'):
            word_vectors = {}
            f=io.open(fname,'r',encoding='utf-8',newline='\n',
            errors='ignore')
            for line in f:
                values = line.strip().rsplit(' ')
                word = values[0]
                coefs = np.asarray(values[1:], dtype='float32')
                word_vectors[word] = coefs
            f.close()
            return word_vectors
        word_vectors=load_fasttext()
        new_list=sorted(words_list)
        word2Ind={}
        value =[]
        key=[]
        key_new=[]
        value_new=[]
        vectors_new=[]
        word2Ind_new=[]
        vectors=[]
        model=fasttext.train_unsupervised(training_text,model='skipgram')
        for x in new_list:
            if x in word_vectors:       
                words=word_vectors[x]
                # rows=[x,words]
                # rows=[words]
                vectors.append(words)
                # for i in range(len(vectors)):
                #     for j in range(len(vectors[i])):
                #         if vectors[i][j] == x:
                #             value.append((i))
                key.append(x)
            else:
                words=model[x]
                vectors_new.append(words)
                # for i in range(len(M_new)):
                #     for j in range(len(M_new[i])):
                #         if vectors_new[i][j] == x:
                #             value_new.append((i))
                key_new.append(x)
        # tmp=[t[0] for t in vectors]
        # M=np.array(tmp)
        M=vectors
        # tmp1=[t[0] for t in vectors_new]
        # M_new=np.array(tmp1)
        for i in range(0,len(key)):
            value.append(i)
        for i in range(0,len(key_new)):
            value_new.append(i)
        M_new=vectors_new
        word2Ind = {k:v for k,v in zip(key,value)}
        word2Ind_new = {k:v for k,v in zip(key_new,value_new)}
        return M, word2Ind, M_new, word2Ind_new

    ## QUES2_A    docs is a list of documents.

    def co_occurrence(self, docs, k=2):
        string=[]
        sub_string=[]
        for i in docs:
            new_i=tokenize.sent_tokenize(i)
            for x in new_i:
                sub_string.append(x)
        string.append(sub_string)
        new_docs=string[0]
        corpus_words = []
        num_corpus_words = -1
        for text in new_docs:
            word_tokens=word_tokenize(text.lower())
            tokenizer = RegexpTokenizer(r'[A-Za-z]+')
            words = tokenizer.tokenize(str(word_tokens))
            corpus_words.append(words)
            result = sorted(set(x for l in corpus_words for x in l))
        num_corpus_words=len(result)
        M = None
        word2Ind = {}
        words=result
        num_words = num_corpus_words
        for i in range(len(words)):
            word2Ind[words[i]]=i
        M=np.zeros((num_words,num_words)) 
        for word in corpus_words:
            for i in range(len(word)):
                target=word[i]
                target_index=word2Ind[target]
                
                left = max(i - k, 0)
                for j in range(left, i):
                    window_word = word[j]
                    M[target_index][word2Ind[window_word]] += 1
                    M[word2Ind[window_word]][target_index] += 1

        return M, word2Ind

    ## QUES2_B     M is co-occurrence matrix.
    def SVD_embedding(self,  M,  m=2):
        # write your implementation here
        n_iters = 10
        M_reduced = None
        print("Running Truncated SVD over %i words..." % (M.shape[0]))
        svd=TruncatedSVD(n_components=m,n_iter=n_iters,random_state=123,tol=0)
        M_reduced=svd.fit_transform(M)
        return M_reduced

    ## QUES2_C
    # #input:
    # #  M_reduced (numpy array of shape (V , k)): k-dimensional word embeddings
    # #  word2Ind (dict): dictionary that maps word to indices for matrix M
    # #  words (list of strings): words whose embeddings we want to visualize
    # def plot_embeddings(self,  M_reduced, word2Ind, words):
    # #     # write your implementation here
    # #     # return statment is not required for this function
    #     for i, word in enumerate(words):
    #         coor=M_reduced[i]
    #         x = coor[0]
    #         y = coor[1]
    #         plt.scatter(x, y, marker = 'x', color = 'red')
    #         plt.text(x + 0.0003, y + 0.0003, word, fontsize = 9)
    #         plt.show()
    # #     # return statment is not required for this function
    #     return M_reduced



# #ques1_4

# stoplist=stopwords.words('english')
# x= 'A large oil spill off the southern California coast was described as an “environmental catastrophe” by the mayor of Huntington Beach on Sunday, as the breach of an oil rig pipeline left dead fish and birds strewn on the sand and offshore wetlands clogged with oil. An estimated 126,000 gallons, or 3,000 barrels, had spread into an oil slick covering about 13 square miles of the Pacific Ocean since it was first reported on Saturday morning, said the mayor of Huntington Beach, at a press conference. The beachside city, about 40 miles south of Los Angeles, was bearing the brunt of the spill'
# word_tokens=word_tokenize(x)
# words_list=[]
# for word in word_tokens:
#     if word.lower() not in stoplist:
#         words_list.append(word)
# tokenizer=RegexpTokenizer(r'\w+')
# words_list=tokenizer.tokenize(str(words_list))
# hw=hw3()
# Mat=hw.get_word2vec_matrix(words_list)[0]
# word2Ind=hw.get_word2vec_matrix(words_list)[1]
# non_exist=hw.get_word2vec_matrix(words_list)[2]
# pd.DataFrame(Mat).to_csv('M_word2vec.csv',header=False, index=False )
# ques1_4 = {'word2Ind':word2Ind, 'non_exist':non_exist}

# #ques1_5

# # tmp=[t[0] for t in Mat]
# # tmp1=np.array(tmp)
# pca = PCA(n_components=2)
# M2d_word2vec = pca.fit_transform(Mat)
# pd.DataFrame(M2d_word2vec).to_csv('M2d_word2vec.csv',header=False, index=False )


# #ques1_6cont

# Mat_glove=hw.get_glove_matrix(words_list)[0]
# word2Ind=hw.get_glove_matrix(words_list)[1] 
# non_exist=hw.get_glove_matrix(words_list)[2]
# pd.DataFrame(Mat_glove).to_csv('M_glove.csv',header=False, index=False )
# ques1_4_glove = {'word2Ind':word2Ind, 'non_exist':non_exist}
# M2d_glove = pca.fit_transform(Mat_glove)
# pd.DataFrame(M2d_glove).to_csv('M2d_glove.csv',header=False, index=False )

# #ques1_7cont

# ##Since fastText is able to create word embedding for unseen words
# # do not eliminate any word from the words list.
# file_name = os.getcwd()+ '/' + 'training_text.txt'  

# Mat_fasttext=hw.get_fasttext_matrix(word_tokens,file_name)[0]
# word2Ind=hw.get_fasttext_matrix(word_tokens,file_name)[1] 
# non_exist=hw.get_fasttext_matrix(word_tokens,file_name)[2]
# pd.DataFrame(Mat_fasttext).to_csv('M_fasttext.csv',header=False, index=False )
# ques1_4_fasttext = {'word2Ind':word2Ind, 'non_exist':non_exist}
# pca = PCA(n_components=2)
# M2d_fasttext = pca.fit_transform(Mat_fasttext)
# pd.DataFrame(M2d_fasttext).to_csv('M2d_fasttext.csv',header=False, index=False )
